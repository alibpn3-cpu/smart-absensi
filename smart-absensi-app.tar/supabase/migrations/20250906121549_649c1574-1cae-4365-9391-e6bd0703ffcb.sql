-- Add division column to staff_users table
ALTER TABLE public.staff_users 
ADD COLUMN division TEXT;